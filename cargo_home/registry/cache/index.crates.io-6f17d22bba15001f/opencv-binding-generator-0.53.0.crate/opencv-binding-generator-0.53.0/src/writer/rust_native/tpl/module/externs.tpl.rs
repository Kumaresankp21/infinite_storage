extern "C" {
	{{code}}
}

