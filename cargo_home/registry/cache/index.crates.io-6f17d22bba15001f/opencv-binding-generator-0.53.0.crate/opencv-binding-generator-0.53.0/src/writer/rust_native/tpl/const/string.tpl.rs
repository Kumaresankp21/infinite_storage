{{doc_comment}}
{{debug}}
pub const {{name}}: &str = {{value}};

