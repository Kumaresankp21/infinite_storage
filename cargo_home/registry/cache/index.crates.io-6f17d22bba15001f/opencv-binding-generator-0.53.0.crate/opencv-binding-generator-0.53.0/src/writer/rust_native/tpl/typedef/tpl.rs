{{doc_comment}}
{{debug}}
pub type {{rust_local}}{{generic_args}} = {{definition}};

