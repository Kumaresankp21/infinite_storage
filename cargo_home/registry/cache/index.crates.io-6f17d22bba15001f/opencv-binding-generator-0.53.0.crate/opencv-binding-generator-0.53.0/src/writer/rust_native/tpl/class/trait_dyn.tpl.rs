impl dyn {{rust_local}} + '_ {
	{{consts}}
	{{const_methods}}
	{{mut_methods}}
}

