{{doc_comment}}
// Duplicate, use {{duplicate_name}} instead
// {{name}} = {{value}},

