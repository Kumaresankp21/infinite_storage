{{doc_comment}}
{{debug}}
pub const {{name}}: usize = {{value}};

