extern "C" {
	{{methods}}
	{{exports}}
}



