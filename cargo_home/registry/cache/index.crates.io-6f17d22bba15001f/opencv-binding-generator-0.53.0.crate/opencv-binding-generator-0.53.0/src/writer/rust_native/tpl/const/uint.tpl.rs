{{doc_comment}}
{{debug}}
pub const {{name}}: u32 = {{value}};

