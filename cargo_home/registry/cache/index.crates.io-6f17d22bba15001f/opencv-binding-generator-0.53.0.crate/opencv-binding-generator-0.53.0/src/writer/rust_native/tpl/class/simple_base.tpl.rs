impl {{base_rust_full}} for {{rust_local}} {
	fn as_raw_{{base_rust_local}}(&self) -> {{base_rust_extern}} { *self }
}


