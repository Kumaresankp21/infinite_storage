{{doc_comment}}
{{debug}}
pub const {{name}}: i32 = {{value}};

