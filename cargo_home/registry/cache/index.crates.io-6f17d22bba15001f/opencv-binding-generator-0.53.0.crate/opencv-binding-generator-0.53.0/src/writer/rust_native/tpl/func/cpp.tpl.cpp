{{attributes_begin}}
{{debug}}
{{return_spec}} {{identifier}}({{decl_args}}) {
	{{try}}
		{{pre_call_args}}
		{{call}}
		{{post_call_args}}
		{{cleanup_args}}
		{{return}}
	{{catch}}
}
{{attributes_end}}


