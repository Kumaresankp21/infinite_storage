{{doc_comment}}
{{name}} = {{value}},

