{{attributes}}
{{debug}}
pub fn {{identifier}}({{args}}){{return_type}};

