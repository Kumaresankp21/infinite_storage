{{doc_comment}}
{{visibility}}{{name}}: {{type}},

