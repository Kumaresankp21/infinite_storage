boxed_cast_base! { {{rust_local}}, {{base_rust_full}}, cv_{{rust_local}}_to_{{base_rust_local}} }


