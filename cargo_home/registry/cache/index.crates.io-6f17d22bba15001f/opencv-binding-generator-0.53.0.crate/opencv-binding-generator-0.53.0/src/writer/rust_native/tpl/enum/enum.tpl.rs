{{doc_comment}}
{{debug}}
#[repr(C)]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum {{rust_local}} {
	{{consts}}
}

opencv_type_enum! { {{rust_full}} }


