{{base_cpp_full}}* cv_{{rust_local}}_to_{{base_rust_local}}({{cpp_decl}}) {
	return dynamic_cast<{{base_cpp_full}}*>(instance);
}


