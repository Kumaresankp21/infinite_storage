impl {{rust_local}} {
	{{consts}}
	{{const_methods}}
	{{mut_methods}}
}


