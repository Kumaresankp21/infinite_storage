{{includes}}
#include "{{module}}_types.hpp"

extern "C" {
	{{code}}
}

