ptr_cast_base! { {{rust_localalias}}, core::Ptr<{{base_rust_full_ref}}>, cv_{{rust_localalias}}_to_PtrOf{{base_rust_local}} }


