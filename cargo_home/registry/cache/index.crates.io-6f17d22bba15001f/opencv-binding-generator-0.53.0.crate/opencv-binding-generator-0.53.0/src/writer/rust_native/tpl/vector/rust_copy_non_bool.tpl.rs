vector_copy_non_bool! { {{inner_rust_full}},
	cv_{{rust_localalias}}_data, cv_{{rust_localalias}}_data_mut, cv_{{rust_localalias}}_from_slice,
	cv_{{rust_localalias}}_clone,
}
