

vector_extern! { {{inner_rust_full}},
	cv_{{rust_localalias}}_new, cv_{{rust_localalias}}_delete,
	cv_{{rust_localalias}}_len, cv_{{rust_localalias}}_is_empty,
	cv_{{rust_localalias}}_capacity, cv_{{rust_localalias}}_shrink_to_fit,
	cv_{{rust_localalias}}_reserve, cv_{{rust_localalias}}_remove,
	cv_{{rust_localalias}}_swap, cv_{{rust_localalias}}_clear,
	cv_{{rust_localalias}}_get, cv_{{rust_localalias}}_set,
	cv_{{rust_localalias}}_push, cv_{{rust_localalias}}_insert,
}
