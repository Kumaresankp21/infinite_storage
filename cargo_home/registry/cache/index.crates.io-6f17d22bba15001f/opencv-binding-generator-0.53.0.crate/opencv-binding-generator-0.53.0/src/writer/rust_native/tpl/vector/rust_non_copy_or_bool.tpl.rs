vector_non_copy_or_bool! { {{clone}}{{inner_rust_full}} }
