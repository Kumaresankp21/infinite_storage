boxed_cast_descendant! { {{rust_local}}, {{descendant_rust_full}}, cv_{{rust_local}}_to_{{descendant_rust_local}} }


