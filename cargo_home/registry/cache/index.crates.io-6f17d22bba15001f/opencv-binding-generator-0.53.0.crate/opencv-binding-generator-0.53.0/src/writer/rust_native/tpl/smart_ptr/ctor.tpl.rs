ptr_extern_ctor! { {{inner_rust_full}}, cv_{{rust_localalias}}_new }


