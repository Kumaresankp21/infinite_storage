extern "C" {
	{{methods}}
}


