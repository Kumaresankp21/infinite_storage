{{doc_comment}}
{{debug}}
{{visibility}}fn {{name}}<T: core::DataType>({{decl_args}}) -> Result<&T> { core::mat_forward::{{name}}(self, {{forward_args}}) }


