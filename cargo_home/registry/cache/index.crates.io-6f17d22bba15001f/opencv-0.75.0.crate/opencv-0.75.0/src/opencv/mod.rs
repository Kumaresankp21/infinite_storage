#[allow(
	dead_code,
	deprecated,
	non_camel_case_types,
	non_snake_case,
	non_upper_case_globals,
	overflowing_literals,
	unused_imports,
)]
#[allow(
	clippy::double_must_use,
	clippy::let_and_return,
	clippy::tabs_in_doc_comments,
	clippy::unnecessary_operation,
)]
#[rustfmt::skip]
pub mod hub;
