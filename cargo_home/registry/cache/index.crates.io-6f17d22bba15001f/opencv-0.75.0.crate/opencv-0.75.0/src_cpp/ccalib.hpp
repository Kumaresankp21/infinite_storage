#include "ocvrs_common.hpp"
#include <opencv2/ccalib.hpp>
#include <opencv2/ccalib/multicalib.hpp>
