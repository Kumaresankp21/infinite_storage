#include "ocvrs_common.hpp"
#include <opencv2/aruco.hpp>
#include <opencv2/aruco/charuco.hpp>
