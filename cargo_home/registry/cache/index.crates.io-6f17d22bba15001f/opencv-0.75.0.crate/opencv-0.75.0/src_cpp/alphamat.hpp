// alphamat.hpp doesn't include core.hpp
#include "ocvrs_common.hpp"
#include <opencv2/alphamat.hpp>
