#define HAVE_OPENCV_OCL // 3.2

#include "ocvrs_common.hpp"
#include <opencv2/bioinspired.hpp>
