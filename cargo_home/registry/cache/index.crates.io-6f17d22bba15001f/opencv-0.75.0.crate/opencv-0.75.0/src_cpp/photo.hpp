#include "ocvrs_common.hpp"
#include <opencv2/photo.hpp>
#include <opencv2/photo/cuda.hpp>
