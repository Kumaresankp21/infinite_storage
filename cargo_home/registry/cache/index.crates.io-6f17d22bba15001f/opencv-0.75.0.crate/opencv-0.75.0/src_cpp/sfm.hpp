#define CERES_FOUND true

#include "ocvrs_common.hpp"
#include <opencv2/sfm.hpp>
#include <opencv2/sfm/robust.hpp>
